package com.example.demo;

import java.sql.Struct;

public class Search_func {
	public Search_func()
	{
	    String field1, field2, field3;
	};
	 
	void buildGraph(Search_func arr[], int n, int *mat[])
	{

	    for (int i=0; i<n; i++)
	       for (int j=0; j<n; j++)
	           mat[i][j] = 0;
	 
	    for (int i = 0; i < n; i++) {
	 
	        for (int j = i+1; j < n; j++)
	            if (arr[i].field1 == arr[j].field1 ||
	                arr[i].field1 == arr[j].field2 ||
	                arr[i].field1 == arr[j].field3 ||
	                arr[i].field2 == arr[j].field1 ||
	                arr[i].field2 == arr[j].field2 ||
	                arr[i].field2 == arr[j].field3 ||
	                arr[i].field3 == arr[j].field1 ||
	                arr[i].field3 == arr[j].field2 ||
	                arr[i].field3 == arr[j].field3)
	            {
	                mat[i][j] = 1;
	                mat[j][i] = 1;
	                break;
	            }
	    }
	}
	 
	void DFSvisit(int i, int *mat[], bool visited[], vector<int>& sol, int n)
	{
	    visited[i] = true;
	    sol.push_back(i);
	 
	    for (int j = 0; j < n; j++)
	        if (mat[i][j] && !visited[j])
	            DFSvisit(j, mat, visited, sol, n);
	}
	
	void findSameContacts(Search_func arr[], int n)
	{
	    // vector for storing the solution
	    vector<int> sol;
	 
	 
	    int **mat = new int*[n];
	 
	    for (int i = 0; i < n; i++)
	        mat[i] = new int[n];
	 

	    bool visited[n];
	    memset(visited, 0, sizeof(visited));
	 

	    buildGraph(arr, n, mat);
	 
	 
	    for (int i = 0; i < n; i++)
	    {
	        if (!visited[i])
	        {
	            DFSvisit(i, mat, visited, sol, n);
	 
	   .
	            sol.push_back(-1);
	        }
	    }
	 
	    for (int i = 0; i < sol.size(); i++)
	        if (sol[i] == -1) System.out.println();
	        else System.out.println(sol[i]+" ");
	}
}
