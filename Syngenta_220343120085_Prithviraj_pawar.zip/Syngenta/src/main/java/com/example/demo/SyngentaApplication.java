package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SyngentaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SyngentaApplication.class, args);
		
		Search_func arr[] = {{"Gaurav", "gaurav@gmail.com", "gaurav@gfgQA.com"},
                {"Lucky", "lucky@gmail.com", "+1234567"},
                {"gaurav123", "+5412312", "gaurav123@skype.com"},
                {"gaurav1993", "+5412312", "gaurav@gfgQA.com"},
                {"raja", "+2231210", "raja@gfg.com"},
                {"bahubali", "+878312", "raja"}
               };

int n = sizeof(arr) / sizeof arr[0];
findSameContacts(arr, n);
return 0;
	}

}
